package com.rame.demospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
